//
//  SettingViewController.swift
//  News
//
//  Created by Jianrui Pei on 3/5/2022.
//

import Foundation
import UIKit

class SettingViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}
